# What is the source of beta-carotene in the Kids Chewable Multivitamin?

The source of beta-carotene in our Kids Chewable Multivitamin is carrots in the vegetable blend.