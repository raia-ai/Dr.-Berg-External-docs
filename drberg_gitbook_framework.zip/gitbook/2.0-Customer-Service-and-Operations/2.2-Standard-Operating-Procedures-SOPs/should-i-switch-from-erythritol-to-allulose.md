# Should I switch from erythritol to allulose?

Yes, you can replace erythritol with allulose. However, allulose is slightly less sweet than erythritol, and you may have to adjust the quantity to achieve the desired sweetness.