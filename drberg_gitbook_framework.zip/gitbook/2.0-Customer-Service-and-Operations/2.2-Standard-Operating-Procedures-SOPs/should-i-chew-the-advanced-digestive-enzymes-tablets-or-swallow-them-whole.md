# Should I chew the Advanced Digestive Enzymes tablets, or swallow them whole?

Chewing Advanced Digestive Enzymes tablets is not advised or necessary. They contain betaine hydrochloride, which may be harmful to teeth and irritate the esophagus. The tablets are less compact than most supplement tablets, which helps them dissolve in the stomach easily, and eliminates the need to chew them.