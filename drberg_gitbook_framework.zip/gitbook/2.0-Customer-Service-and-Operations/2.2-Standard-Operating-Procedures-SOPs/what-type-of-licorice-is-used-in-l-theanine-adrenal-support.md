# What type of licorice is used in L-Theanine Adrenal Support?

We use a licorice root powder in the L-Theanine Adrenal Support. It is not DGL