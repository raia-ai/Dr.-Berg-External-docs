# Did the color of the Kids Multivitamin Chewable wafer change?

Yes, you'll notice a color change in the Kids Multivitamin Wafer. It's now pink, rather than the previous brown color.