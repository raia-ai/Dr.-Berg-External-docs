# Is silicon dioxide synthetic?

Silicon Dioxide is synthetic.