# How is allithiamine extracted for the Natural B1+ Allithiamine with B Complex Blend?

We use an ethanol extraction process to create our Natural B1+, which produces the beneficial compound allithiamine from garlic.