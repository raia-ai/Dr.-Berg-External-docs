# What is the animal source of the gelatin capsule used in the Sleep Aid?

Our Sleep Aid uses bovine-sourced gelatin capsules.