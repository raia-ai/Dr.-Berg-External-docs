# Does Probiotics with Prebiotic Blend supplement contain soy, wheat, dairy or nuts?

Our Probiotics with Prebiotic Blend is formulated without common allergens, including soy, wheat, dairy, and nuts.