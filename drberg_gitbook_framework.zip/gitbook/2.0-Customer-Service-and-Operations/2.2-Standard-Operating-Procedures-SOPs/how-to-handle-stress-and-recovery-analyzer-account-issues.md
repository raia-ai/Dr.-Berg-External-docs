# How to handle Stress And Recovery Analyzer account issues?

If a Stress and Recovery Analyzer customer has an issue logging in to their account or would like to delete their account, they must contact Binacor directly at support@bodyhealthanalyzer.com mailto:support@bodyhealthanalyzer.com.