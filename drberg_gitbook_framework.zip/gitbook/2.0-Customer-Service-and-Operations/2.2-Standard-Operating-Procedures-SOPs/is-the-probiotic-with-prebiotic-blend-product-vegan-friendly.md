# Is the Probiotic with Prebiotic Blend product vegan-friendly?

Yes! This product is 100% vegan friendly!