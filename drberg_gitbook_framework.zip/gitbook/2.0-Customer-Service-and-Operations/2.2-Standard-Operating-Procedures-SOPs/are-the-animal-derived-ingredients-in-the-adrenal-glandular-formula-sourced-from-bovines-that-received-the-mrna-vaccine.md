# Are the animal-derived ingredients in the Adrenal Glandular Formula sourced from bovines that received the mRNA vaccine?

The bovine used in our Adrenal Glandular Formula were not given the mRNA vaccine.