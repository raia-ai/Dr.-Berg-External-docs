# Why does D3 & K2 with Zinc & MCT Oil have a grainy texture?

If you notice a grainy texture in our D3 & K2 with Zinc & MCT Oil, it's likely due to the zinc settling at the bottom of the bottle between uses. A quick shake before each use will redistribute the zinc and help with a grainy texture.