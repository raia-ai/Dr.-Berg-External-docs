# Are the B vitamins in Natural B1+ Allithiamine with B Complex Blend in their active form?

Our Natural B1+ provides B vitamins in their active, methylated form for optimal absorption and utilization by the body.