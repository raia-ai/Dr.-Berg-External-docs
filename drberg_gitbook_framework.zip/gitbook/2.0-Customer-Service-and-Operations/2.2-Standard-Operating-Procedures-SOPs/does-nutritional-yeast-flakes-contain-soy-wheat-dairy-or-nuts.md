# Does Nutritional Yeast Flakes contain soy, wheat, dairy or nuts?

Our Nutritional Yeast Flakes are formulated without common allergens, including soy, wheat, dairy, and nuts.