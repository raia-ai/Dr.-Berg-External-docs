# Should all four capsules of Glucosamine Chondroitin be taken at once?

You have the option to take all four capsules of our Glucosamine Chondroitin Advanced Joint Support at once or take them at separate times.