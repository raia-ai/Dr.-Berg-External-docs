# What trace minerals are included in the Electrolyte Powder?

The trace minerals in our Electrolyte Powder are identical to those found in Trace Minerals Enhanced, a diverse blend of 70 minerals in small amounts. The blend is proprietary.