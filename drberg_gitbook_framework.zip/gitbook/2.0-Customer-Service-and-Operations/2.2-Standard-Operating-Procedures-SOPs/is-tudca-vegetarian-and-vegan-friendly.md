# Is TUDCA vegetarian and vegan-friendly?

Yes, Dr. Berg TUDCA supplement is both vegetarian and vegan-friendly.