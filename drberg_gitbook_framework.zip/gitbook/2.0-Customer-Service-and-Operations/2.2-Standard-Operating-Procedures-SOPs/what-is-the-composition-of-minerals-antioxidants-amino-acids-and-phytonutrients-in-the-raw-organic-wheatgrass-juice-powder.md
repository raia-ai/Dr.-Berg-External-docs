# What is the composition of minerals, antioxidants, amino acids, and phytonutrients in the Raw Organic Wheatgrass Juice Powder?

The Wheatgrass Juice Powder has not been analyzed for the breakdown of minerals, antioxidants, amino acids, and phytonutrients. It is a nutritional product, not a supplement product.