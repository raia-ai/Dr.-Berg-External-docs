# Does Friendly Bacteria Probiotic Liquid with 12 Probiotic Strains contain soy, wheat, dairy or nuts?

Our Friendly Bacteria Probiotic Liquid is formulated without common allergens, including soy, wheat, dairy, and nuts.