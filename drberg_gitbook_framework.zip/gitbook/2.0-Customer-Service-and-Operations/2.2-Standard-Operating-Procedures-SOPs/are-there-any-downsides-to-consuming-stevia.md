# Are there any downsides to consuming stevia?

The use of stevia is considered safe, and most people can consume stevia-sweetened food and beverages without side effects. However, individuals with a sensitive digestive tract may experience gastrointestinal issues such as bloating, gas, and abdominal pain when consuming stevia in high concentrations.