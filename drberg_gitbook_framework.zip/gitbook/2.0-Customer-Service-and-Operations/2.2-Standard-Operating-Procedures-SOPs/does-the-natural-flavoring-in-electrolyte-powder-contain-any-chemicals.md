# Does the natural flavoring in Electrolyte Powder contain any chemicals?

The natural flavors in our Electrolyte Powder are free from synthetic chemicals.