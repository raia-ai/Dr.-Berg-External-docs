# Why isn't magnesium glycinate used in our Electrolyte Powder?

We maybe making this change in the future.