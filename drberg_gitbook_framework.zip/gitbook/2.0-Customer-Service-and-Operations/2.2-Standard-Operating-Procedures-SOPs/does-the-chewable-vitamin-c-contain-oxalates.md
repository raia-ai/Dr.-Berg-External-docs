# Does the Chewable Vitamin C contain oxalates?

Our Chewable Vitamin C Complex is oxalate-free.