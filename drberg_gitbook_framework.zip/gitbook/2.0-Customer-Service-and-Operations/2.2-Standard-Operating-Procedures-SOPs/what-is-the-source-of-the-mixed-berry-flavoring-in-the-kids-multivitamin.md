# What is the source of the mixed berry flavoring in the Kids Multivitamin?

We use natural flavors extracted from real berries to give our Kids Multivitamin its tasty mixed berry flavor.