# Does Hair Formula supplement contain soy, wheat, dairy or nuts?

Dr. Berg's Hair Formula is formulated without common allergens, including soy, wheat, dairy, and nuts.