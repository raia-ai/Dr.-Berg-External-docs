# What is the softgel capsule of Omega 3 Cod Liver Fish Oil made from?

Every soft gel capsule of Omega 3 Cod Liver Fish Oil made of gelatin, glycerin, purified water and natural lemon flavor.