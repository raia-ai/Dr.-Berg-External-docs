# What is the calorie content of the Electrolyte Powder?

Each scoop of the Electrolyte Powder has 15 calories.