# Is it okay to consume hard alcohol while fasting?

It’s not recommended to consume hard liquor while fasting. Whenever you drink alcohol, your liver can’t break down and metabolize fat which interferes with ketosis and breaks a fast. Drinking any type of alcohol while fasting slows weight loss and inhibits autophagy.