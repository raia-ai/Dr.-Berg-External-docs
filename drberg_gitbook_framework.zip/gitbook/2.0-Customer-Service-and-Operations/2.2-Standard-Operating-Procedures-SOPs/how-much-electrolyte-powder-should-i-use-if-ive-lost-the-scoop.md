# How much Electrolyte Powder should I use if I’ve lost the scoop?

Misplaced your Electrolyte Powder scooper? Here's how to measure one serving:1.2 teaspoons (tsp)6 grams