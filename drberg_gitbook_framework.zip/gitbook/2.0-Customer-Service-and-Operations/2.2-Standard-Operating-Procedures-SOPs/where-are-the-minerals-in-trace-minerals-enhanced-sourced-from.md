# Where are the minerals in Trace Minerals Enhanced sourced from?

The trace minerals in our Trace Minerals Enhanced product are derived from the naturally evaporated seawater of the Great Salt Lake, a rich source of essential minerals.