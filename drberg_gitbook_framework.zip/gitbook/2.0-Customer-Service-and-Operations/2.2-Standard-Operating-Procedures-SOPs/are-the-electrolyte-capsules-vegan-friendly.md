# Are the Electrolyte Capsules vegan-friendly?

Our Electrolyte Capsules are vegan-friendly.