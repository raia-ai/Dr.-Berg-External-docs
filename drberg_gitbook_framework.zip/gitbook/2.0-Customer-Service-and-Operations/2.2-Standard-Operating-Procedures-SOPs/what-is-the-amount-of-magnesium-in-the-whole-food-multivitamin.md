# What is the amount of magnesium in the Whole Food Multivitamin?

Whole Food Multivitamin contains 307 mg of magnesium in total. This includes 57 mg sourced from whole fruits and vegetables and an additional 250 mg from Kreb Cycle powder.