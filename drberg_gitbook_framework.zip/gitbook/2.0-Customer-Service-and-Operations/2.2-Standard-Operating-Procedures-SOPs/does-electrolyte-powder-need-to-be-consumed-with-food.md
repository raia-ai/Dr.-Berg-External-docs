# Does Electrolyte Powder need to be consumed with food?

No, we recommend drinking it on an empty stomach.