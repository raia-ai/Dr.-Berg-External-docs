# Has the Raw Wheatgrass Juice Powder been tested for the presence of heavy metals?

Absolutely! All of our products, including our Raw Organic Wheatgrass Juice Powder, undergo rigorous third-party testing for heavy metals. We're committed to ensuring they meet the highest safety standards.