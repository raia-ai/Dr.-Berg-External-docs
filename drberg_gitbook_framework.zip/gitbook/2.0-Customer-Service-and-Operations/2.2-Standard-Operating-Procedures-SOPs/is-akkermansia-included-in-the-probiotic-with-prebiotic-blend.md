# Is akkermansia included in the Probiotic with Prebiotic Blend?

Akkermansia is not listed on our Probiotic with Prebiotic Blend label, and we haven't tested for its presence.