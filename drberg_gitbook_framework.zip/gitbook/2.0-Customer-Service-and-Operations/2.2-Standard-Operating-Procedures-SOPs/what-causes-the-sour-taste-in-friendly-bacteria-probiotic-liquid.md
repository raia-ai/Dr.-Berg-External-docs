# What causes the sour taste in Friendly Bacteria Probiotic Liquid?

Friendly Bacteria Probiotic has a sour taste because it's fermented! Fermentation by good bacteria naturally creates a slightly tart flavor.