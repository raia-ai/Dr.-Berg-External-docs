# Does the Omega 3 Cod Liver Fish Oil supplement smell like fish?

No, Omega 3 Cod Liver Fish Oil soft gel capsules have a pleasant lemon taste which makes it easier to take the Cod Liver Fish oil.