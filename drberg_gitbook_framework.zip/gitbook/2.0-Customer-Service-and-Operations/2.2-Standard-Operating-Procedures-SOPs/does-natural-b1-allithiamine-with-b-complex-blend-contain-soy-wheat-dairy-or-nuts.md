# Does Natural B1+ Allithiamine with B Complex Blend contain soy, wheat, dairy or nuts?

Our Natural B1+ vitamins are formulated without common allergens, including soy, wheat, dairy, and nuts.