# What substrate was used to grow the Nutritional Yeast Flakes?

Beet molasses is used as a growth medium for our Nutritional Yeast Flakes.