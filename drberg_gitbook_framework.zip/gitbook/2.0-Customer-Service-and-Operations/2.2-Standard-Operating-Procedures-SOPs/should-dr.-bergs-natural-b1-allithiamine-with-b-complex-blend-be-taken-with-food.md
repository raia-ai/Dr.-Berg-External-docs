# Should Dr. Berg's Natural B1+ Allithiamine with B Complex Blend be taken with food?

Unlike fat-soluble supplements, you can take our Natural B1+ Vitamins with or without food.