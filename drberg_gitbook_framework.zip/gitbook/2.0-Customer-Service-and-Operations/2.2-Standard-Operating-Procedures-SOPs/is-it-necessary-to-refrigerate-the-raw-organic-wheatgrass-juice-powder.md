# Is it necessary to refrigerate the Raw Organic Wheatgrass Juice Powder?

We don't recommend refrigerating our Raw Organic Wheatgrass Juice Powder. Moisture from condensation can cause the powder to clump and solidify. For best results, store it in a cool, dry place.