# What is the amount of Lactobacillus Salivarius in the Probiotic with Prebiotic Blend?

The exact probiotic strain composition can naturally vary from batch to batch since we use a natural source. We cannot provide a breakdown of individual strains.