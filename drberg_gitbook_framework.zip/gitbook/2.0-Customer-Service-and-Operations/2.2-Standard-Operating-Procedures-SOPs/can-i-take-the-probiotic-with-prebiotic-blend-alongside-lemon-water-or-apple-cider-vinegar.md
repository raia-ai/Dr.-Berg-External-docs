# Can I take the Probiotic with Prebiotic Blend alongside lemon water or apple cider vinegar?

Dr. Berg Probiotic with Prebiotic Blend acid-resistant capsule ensures it remains effective, even when taken with acidic drinks like lemon juice or apple cider vinegar.