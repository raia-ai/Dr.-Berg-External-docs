# Are any ingredients in Dr. Berg Vitamin D3 & K2 sourced from China?

To confirm, we do not source any ingredients from China for our Vitamin D3 & K2 products.