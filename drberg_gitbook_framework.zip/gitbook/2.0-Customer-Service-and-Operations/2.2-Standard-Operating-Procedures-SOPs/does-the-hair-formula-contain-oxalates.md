# Does the Hair Formula contain oxalates?

We have not tested our Hair Formula for oxalate content.