# Has the Whole Food Multivitamin been tested for Glyphosate?

Our Whole Food Multivitamin has not been tested for glyphosate because it is not certified organic.