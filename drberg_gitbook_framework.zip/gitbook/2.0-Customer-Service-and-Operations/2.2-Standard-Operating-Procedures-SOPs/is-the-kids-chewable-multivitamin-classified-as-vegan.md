# Is the Kid's Chewable Multivitamin classified as vegan?

Yes the Kid's Chewable Multivitamin is vegan.