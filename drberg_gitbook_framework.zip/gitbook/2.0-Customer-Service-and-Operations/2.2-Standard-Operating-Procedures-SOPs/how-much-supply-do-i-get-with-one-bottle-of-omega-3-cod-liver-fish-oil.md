# How much supply do I get with one bottle of Omega 3 Cod Liver Fish Oil?

With every bottle of Omega 3 Cod Liver Fish Oil you get 60 Day supply.