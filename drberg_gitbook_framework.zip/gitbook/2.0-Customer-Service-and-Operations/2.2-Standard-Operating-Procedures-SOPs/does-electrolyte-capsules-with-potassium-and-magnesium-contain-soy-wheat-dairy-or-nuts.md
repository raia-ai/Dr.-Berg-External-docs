# Does Electrolyte Capsules with Potassium and Magnesium contain soy, wheat, dairy or nuts?

Our Electrolyte Capsules are formulated without common allergens, including soy, wheat, dairy, and nuts.