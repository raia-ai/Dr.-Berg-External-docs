# What can I consume during a 24-hour fast?

The general rule of a 24-hour fast is to abstain from all foods. However, small amounts of foods like celery and lettuce (without dressing) may not break a fast.