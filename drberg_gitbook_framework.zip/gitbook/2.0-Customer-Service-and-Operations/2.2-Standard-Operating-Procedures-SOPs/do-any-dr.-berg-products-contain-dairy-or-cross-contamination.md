# Do any Dr. Berg products contain dairy or cross-contamination?

Dr. Berg products are completely dairy-free and there's no risk of cross-contamination.