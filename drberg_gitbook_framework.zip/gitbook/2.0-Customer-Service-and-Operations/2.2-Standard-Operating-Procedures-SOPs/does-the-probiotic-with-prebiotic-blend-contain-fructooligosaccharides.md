# Does the Probiotic with Prebiotic Blend contain Fructooligosaccharides?

Dr. Berg's Probiotic with Prebiotic Blend formula does not contain FOS (Fructooligosaccharides). While the whole artichoke can be a source of FOS, the Artichoke Leaf Extract used in our formula is not. The other prebiotic ingredients included are also not sources of FOS.