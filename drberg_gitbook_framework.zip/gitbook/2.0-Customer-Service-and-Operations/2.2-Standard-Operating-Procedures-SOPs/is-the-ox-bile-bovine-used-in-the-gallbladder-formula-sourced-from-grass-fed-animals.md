# Is the ox bile (bovine) used in the Gallbladder Formula sourced from grass-fed animals?

The ox bile (bovine) in our Gallbladder Formula Extra Strength is sourced from grass-fed animals.