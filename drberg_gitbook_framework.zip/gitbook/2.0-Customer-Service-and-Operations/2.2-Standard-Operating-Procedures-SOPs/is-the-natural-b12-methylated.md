# Is the Natural B12 methylated?

Yes, B12 (methylcobalamin) is methylated, and the other B vitamins come from a whole food source.