# Where is the cellulose in the Chewable Vitamin C Complex sourced from?

The cellulose (microcrystalline cellulose) in our Chewable Vitamin C Complex is sourced from palm fibers.