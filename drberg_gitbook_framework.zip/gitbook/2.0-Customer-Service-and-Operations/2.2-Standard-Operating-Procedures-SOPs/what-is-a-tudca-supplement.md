# What is a TUDCA supplement?

Tauroursodeoxycholic acid, a potent form of bile acid to enhance liver and gallbladder health