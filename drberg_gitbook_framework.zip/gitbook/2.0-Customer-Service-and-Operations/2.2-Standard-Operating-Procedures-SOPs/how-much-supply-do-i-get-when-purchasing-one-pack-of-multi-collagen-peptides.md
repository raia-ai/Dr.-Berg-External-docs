# How much supply do I get when purchasing one pack of Multi Collagen Peptides?

With every purchase of Multi Collagen Peptides pack, you get 25 day supply!