# What is the amount of vitamin B12 in the Natural Prenatal Vitamin?

Our Natural Prenatal Vitamins are formulated without vitamin B12.