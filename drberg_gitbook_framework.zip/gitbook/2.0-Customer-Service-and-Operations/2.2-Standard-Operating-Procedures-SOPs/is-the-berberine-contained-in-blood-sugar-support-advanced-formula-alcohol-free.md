# Is the berberine contained in Blood Sugar Support Advanced Formula alcohol-free?

Our Blood Sugar Support Advanced Formula contains alcohol-free berberine.