# Which blue light filter glasses does Dr. Berg recommend, and what features make them effective?

Dr. Berg recommends: NSI N-Specs® Xcelerator® Amber Lens Safety GlassesWebsite: https://www.northernsafety.com/Product/32314/Amber-Lens-Safety-Glasses