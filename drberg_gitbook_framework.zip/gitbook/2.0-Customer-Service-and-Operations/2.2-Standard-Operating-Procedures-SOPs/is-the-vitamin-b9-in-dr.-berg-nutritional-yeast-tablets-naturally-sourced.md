# Is the vitamin B9 in Dr. Berg Nutritional Yeast Tablets naturally sourced?

The B vitamins in both products are naturally occurring, except for the B12 in the Nutritional Yeast tablets, which is added.