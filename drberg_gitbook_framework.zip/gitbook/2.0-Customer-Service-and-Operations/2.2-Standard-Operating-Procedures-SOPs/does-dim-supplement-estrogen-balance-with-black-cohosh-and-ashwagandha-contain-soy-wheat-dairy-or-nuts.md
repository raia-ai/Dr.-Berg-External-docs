# Does DIM Supplement Estrogen Balance with Black Cohosh and Ashwagandha contain soy, wheat, dairy or nuts?

Our DIM Supplement Estrogen Balance is formulated without common allergens, including soy, wheat, dairy, and nuts.