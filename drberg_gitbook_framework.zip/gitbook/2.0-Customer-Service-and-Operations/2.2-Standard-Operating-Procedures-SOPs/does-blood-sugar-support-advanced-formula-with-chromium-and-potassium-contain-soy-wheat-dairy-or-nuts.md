# Does Blood Sugar Support Advanced Formula with Chromium and Potassium contain soy, wheat, dairy or nuts?

Our Blood Sugar Support Advanced Formula is formulated without common allergens, including soy, wheat, dairy, and nuts.