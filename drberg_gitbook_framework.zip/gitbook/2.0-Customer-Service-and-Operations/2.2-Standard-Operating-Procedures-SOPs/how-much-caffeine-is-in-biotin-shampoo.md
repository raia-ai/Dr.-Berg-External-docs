# How much caffeine is in Biotin Shampoo?

Our Biotin Shampoo contains only a trace amount of caffeine (0.03%).