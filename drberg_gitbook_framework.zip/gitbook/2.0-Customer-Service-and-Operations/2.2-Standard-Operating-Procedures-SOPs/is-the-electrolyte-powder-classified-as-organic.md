# Is the Electrolyte Powder classified as organic?

Our Electrolyte Powder contains organic fruit along with other organic ingredients. We are in the process of obtaining organic certification.