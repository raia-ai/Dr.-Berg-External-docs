# What form of vitamin K is used in the Natural Prenatal Supplement?

Our Natural Prenatal Vitamins contain vitamin K1.