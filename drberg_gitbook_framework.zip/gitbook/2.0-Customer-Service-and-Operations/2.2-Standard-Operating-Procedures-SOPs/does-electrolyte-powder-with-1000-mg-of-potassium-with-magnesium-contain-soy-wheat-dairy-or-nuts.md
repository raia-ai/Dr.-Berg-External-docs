# Does Electrolyte Powder with 1000 mg of Potassium with Magnesium contain soy, wheat, dairy or nuts?

Our Electrolyte Powder is formulated without common allergens, including soy, wheat, dairy, and nuts.