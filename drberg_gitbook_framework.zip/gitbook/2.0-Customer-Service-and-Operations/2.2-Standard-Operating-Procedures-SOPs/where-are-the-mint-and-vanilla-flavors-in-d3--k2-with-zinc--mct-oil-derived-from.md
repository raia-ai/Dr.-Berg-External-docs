# Where are the mint and vanilla flavors in D3 & K2 with Zinc & MCT Oil derived from?

We use only pure, natural vanilla and mint flavors in our D3 & K2 with Zinc & MCT Oil, ensuring a synthetic-free experience.