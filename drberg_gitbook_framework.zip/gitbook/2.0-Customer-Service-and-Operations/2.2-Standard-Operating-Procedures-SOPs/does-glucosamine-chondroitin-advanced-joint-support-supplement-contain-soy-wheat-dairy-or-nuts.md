# Does Glucosamine Chondroitin Advanced Joint Support supplement contain soy, wheat, dairy or nuts?

Our Glucosamine Chondroitin Advanced Joint Support is formulated without common allergens, including soy, wheat, dairy, and nuts. However, this formula does contain shellfish.