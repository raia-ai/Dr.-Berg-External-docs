# Are white specks at the bottom of Vitamin D3 & K2 with Zinc & MCT Oil normal?

White specks at the bottom of the Vitamin D3 & K2 with Zinc & MCT Oil bottle are normal. The zinc in the product will settle to the bottom of the bottle between uses. A quick shake before each use will redistribute the zinc.