# What is the amount of trace minerals in the Sports Hydration Electrolyte Powder?

Each serving of our Sports Hydration Electrolyte Powder delivers 100mg of trace minerals to support your active lifestyle