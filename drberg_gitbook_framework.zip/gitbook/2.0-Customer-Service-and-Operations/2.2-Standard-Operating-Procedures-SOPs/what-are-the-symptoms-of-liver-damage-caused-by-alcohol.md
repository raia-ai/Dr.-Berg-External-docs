# What are the symptoms of liver damage caused by alcohol?

Signs of alcohol-related liver damage include jaundice, abdominal pain or swelling, persistent fatigue, easy bruising, mental confusion, or memory problems.