# Is gluten included in the ingredients of Probiotic with Prebiotic Blend Capsules supplement?

Unfortunately, we do not have information on this. Further testing is required