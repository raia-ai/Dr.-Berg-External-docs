# What type of processing do the whole food ingredients in the Whole Food Multivitamin undergo?

The fruits and vegetables in our Whole Food Multivitamin are freeze-dried to preserve their nutritional value.