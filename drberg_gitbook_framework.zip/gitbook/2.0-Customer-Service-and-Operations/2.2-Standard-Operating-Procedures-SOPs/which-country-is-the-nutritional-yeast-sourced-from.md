# Which country is the nutritional yeast sourced from?

Nutritional Yeast is sourced from Mexico.