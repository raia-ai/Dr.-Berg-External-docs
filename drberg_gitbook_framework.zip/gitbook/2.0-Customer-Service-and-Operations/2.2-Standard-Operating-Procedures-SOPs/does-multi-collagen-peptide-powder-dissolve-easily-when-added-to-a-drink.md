# Does Multi Collagen Peptide powder dissolve easily when added to a drink?

Yes, the powder dissolves fast and easy!