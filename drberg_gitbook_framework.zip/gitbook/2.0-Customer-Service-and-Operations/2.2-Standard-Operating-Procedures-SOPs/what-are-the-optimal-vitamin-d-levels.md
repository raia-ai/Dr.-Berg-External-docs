# What are the optimal Vitamin D Levels?

It is vital to keep your vitamin D levels over 50 ng/mL to avoid vitamin D deficiency.