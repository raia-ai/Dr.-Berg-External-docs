# Is it necessary to take vitamins D3 and K2 with food?

It is not necessary to take this supplement with a meal because it includes medium-chain triglycerides and bile salts which aid in the absorption of the vitamins. However, you may still choose to take the capsules with your first meal if you prefer.