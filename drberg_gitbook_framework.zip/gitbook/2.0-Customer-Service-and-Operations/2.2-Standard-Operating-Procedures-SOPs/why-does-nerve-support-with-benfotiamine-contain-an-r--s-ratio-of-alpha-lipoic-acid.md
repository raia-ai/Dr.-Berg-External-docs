# Why does Nerve Support with Benfotiamine contain an R & S ratio of Alpha Lipoic Acid?

Capsule size restrictions prevented us from using only r-ALA in our Nerve Support with Benfotamine to reach the necessary ALA concentration. Our vendor added s-ALA, a more concentrated form, to meet this requirement.