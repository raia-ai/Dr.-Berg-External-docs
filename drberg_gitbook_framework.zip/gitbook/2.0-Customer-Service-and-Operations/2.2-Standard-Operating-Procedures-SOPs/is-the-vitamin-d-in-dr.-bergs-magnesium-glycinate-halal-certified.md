# Is the Vitamin D in Dr. Berg's Magnesium Glycinate halal-certified?

The Vitamin D in our Magnesium Glycinate is derived from sheep's wool. Please note that the product itself is not certified as halal.