# Where is the betaine hydrochloride in Advanced Digestive Enzymes sourced from?

The betaine hydrochloride in our Advanced Digestive Enzymes is derived from chloroacetic acid and sodium carbonate.