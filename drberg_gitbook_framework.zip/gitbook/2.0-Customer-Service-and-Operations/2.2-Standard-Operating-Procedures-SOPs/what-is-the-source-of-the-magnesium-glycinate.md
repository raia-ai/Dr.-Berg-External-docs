# What is the source of the magnesium glycinate?

Dr. Berg Magnesium Glycinate is derived from mineral ore.