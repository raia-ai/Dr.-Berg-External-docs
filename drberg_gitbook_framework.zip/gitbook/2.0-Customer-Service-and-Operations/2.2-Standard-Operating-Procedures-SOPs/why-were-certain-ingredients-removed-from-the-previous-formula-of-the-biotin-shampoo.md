# Why were certain ingredients removed from the previous formula of the Biotin Shampoo?

We've upgraded our Biotin Shampoo and Conditioner formula, replacing some ingredients with more natural alternatives.