# How many drops of D3 & K2 with Zinc and MCT Oil are in a dropperful?

Our D3 & K2 with Zinc and MCT Oil Contains about 50 drops per dropperful.