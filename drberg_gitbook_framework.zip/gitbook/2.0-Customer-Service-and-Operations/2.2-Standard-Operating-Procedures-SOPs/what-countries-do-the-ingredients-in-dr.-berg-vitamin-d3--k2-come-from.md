# What countries do the ingredients in Dr. Berg Vitamin D3 & K2 come from?

The ingredients in our D3 & K2 Vitamins are sourced from the following countries (in no particular order): USA, India, Israel, Japan, Singapore, and Argentina.