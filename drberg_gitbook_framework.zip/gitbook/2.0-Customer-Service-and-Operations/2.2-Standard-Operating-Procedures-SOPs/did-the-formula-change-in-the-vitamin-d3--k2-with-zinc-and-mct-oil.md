# Did the formula change in the Vitamin D3 & K2 with Zinc and MCT Oil?

The only change was the manufacturer and source of the ingredients. They are of higher quality, but the taste may be a little bit different than before.