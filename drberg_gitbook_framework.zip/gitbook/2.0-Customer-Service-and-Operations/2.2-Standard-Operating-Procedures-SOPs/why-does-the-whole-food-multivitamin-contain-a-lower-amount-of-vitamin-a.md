# Why does the Whole Food Multivitamin contain a lower amount of vitamin A?

The recent test of a blend of Fruits and vegetables in our Whole Food Multivitamin shows the vitamin A amount is lower. It will vary, which is why the blend gets tested every once in a while.