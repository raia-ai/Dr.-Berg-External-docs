# What are the amounts of Bioflavonoids, Natural Ascorbic Acid, and Ascorbate in the Chewable Vitamin C Complex?

We don't currently have specific data on the levels of bioflavonoids, natural ascorbic acid, and ascorbate in our Chewable Vitamin C Complex.