# What brand of stevia is used in the Electrolyte Powder?

Our Electrolyte Powder uses stevia extract directly from the plant rather than a specific brand.