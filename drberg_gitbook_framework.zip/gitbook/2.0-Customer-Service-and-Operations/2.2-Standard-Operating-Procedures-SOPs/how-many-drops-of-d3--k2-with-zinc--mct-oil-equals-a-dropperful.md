# How many drops of D3 & K2 with Zinc & MCT Oil equals a dropperful?

Our D3 & K2 with Zinc and MCT Oil contain about 50 drops per dropperful.