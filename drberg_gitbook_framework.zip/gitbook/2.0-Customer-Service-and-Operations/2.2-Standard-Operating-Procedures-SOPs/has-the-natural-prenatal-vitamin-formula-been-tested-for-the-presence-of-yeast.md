# Has the Natural Prenatal Vitamin formula been tested for the presence of yeast?

Our Natural Prenatal Vitamins have tested negative for microbial growth.