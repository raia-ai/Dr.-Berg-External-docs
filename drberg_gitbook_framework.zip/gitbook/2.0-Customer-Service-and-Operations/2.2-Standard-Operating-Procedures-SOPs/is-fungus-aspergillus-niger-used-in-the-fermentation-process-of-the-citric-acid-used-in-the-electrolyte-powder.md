# Is Fungus Aspergillus Niger used in the fermentation process of the citric acid used in the Electrolyte Powder?

Fungus Aspergillus Niger is used as part of the fermentation process of the citric acid used in the Electrolyte line.