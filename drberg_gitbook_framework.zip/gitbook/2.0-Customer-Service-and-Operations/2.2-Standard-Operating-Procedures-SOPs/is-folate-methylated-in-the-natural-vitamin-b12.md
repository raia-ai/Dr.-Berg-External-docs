# Is folate methylated in the Natural Vitamin B12?

The folate found in the Natural Vitamin B12 supplement is indeed in its natural, methylated form.