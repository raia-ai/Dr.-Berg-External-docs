# From which country is the molasses in the Nutritional Yeast tablets derived?

Our Nutritional Yeast is made using molasses sourced from Mexico.