# Why does the Whole Food Multivitamin include both vitamin D3 and vitamin K2?

Our Whole Food Multivitamin does include some D3, but adding more would require increasing the capsule dosage. Additionally, customers may prefer to adjust their D3 and K2 intake separately, which is why we offer three different D3/K2 products to choose from.