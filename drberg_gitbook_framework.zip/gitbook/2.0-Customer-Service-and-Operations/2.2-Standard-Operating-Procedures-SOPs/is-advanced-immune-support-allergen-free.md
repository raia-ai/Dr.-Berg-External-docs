# Is Advanced Immune Support allergen free?

The Advanced Immune Support contains no allergens. The product is produced in a facility that processes known allergens. However, stringent cleaning procedures and validated tests are conducted after an allergen run to mitigate the risk of cross-contamination.