# Is protein included in the ingredients of the Electrolyte Powder?

Dr. Berg Electrolyte Powder focuses on electrolyte replenishment and does not contain protein.