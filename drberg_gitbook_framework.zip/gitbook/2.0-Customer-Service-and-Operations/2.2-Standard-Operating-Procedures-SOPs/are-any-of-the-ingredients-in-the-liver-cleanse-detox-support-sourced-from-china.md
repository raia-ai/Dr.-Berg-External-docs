# Are any of the ingredients in the Liver Cleanse Detox Support sourced from China?

Our Liver Cleanse Detox Repair Support contains high-quality SAMe and 5-Methyltetrahydrofolate sourced from China.