# Where is the chondroitin sourced from in Glucosamine Chondroitin Advanced Joint Support?

Bovine cartilage is the source of chondroitin in our Glucosamine Chondroitin Advanced Joint Support.