# Does Gallbladder Formula Extra Strength with Ox Bile and Digestive Enzymes contain soy, wheat, dairy or nuts?

Our Gallbladder Formula Extra Strength is formulated without common allergens, including soy, wheat, dairy, and nuts.