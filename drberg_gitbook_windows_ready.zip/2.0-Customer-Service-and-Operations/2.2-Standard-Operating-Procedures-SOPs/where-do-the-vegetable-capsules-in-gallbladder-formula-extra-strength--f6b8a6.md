# Where do the vegetable capsules in Gallbladder Formula Extra Strength come from?

The vegetable capsule source is a blend of cellulose and water. The amount of cellulose used is minimal.