# Is heat involved in the manufacturing of Chewable Vitamin C wafers?

Our Chewable Vitamin C Complex we use freeze-drying technology to preserve the quality of our ingredients. You can find details on the product page and the ingredient label.