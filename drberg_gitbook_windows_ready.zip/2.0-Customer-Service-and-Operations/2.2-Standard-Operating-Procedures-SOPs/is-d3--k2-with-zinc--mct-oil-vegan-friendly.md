# Is D3 & K2 with Zinc & MCT Oil vegan-friendly?

Our D3 & K2 with Zinc & MCT Oil is not vegan-friendly as the D3 is sourced from lanolin (sheep wool).