# Should the Glucosamine Chondroitin be taken with food?

Our Glucosamine Chondroitin Advanced Joint Support can be taken with or without food.