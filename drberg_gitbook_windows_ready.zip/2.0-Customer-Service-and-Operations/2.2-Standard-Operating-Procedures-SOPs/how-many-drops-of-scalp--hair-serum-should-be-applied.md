# How many drops of Scalp & Hair Serum should be applied?

The ideal amount of Scalp & Hair Serum will vary from person to person. Start with a small amount and gradually increase until you achieve your desired results.