# Is the Natural Prenatal Vitamin organic?

Our Natural Prenatal Vitamins are made with organic ingredients, but they are not certified organic at this time.