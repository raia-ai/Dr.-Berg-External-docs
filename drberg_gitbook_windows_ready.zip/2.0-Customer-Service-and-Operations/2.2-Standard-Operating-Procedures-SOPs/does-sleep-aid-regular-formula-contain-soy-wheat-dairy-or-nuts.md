# Does Sleep Aid Regular Formula contain soy, wheat, dairy or nuts?

Dr. Berg's Sleep Aid is formulated without common allergens, including soy, wheat, dairy, and nuts.