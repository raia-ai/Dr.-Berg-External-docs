# What is the carbohydrate content of the nutritional yeast?

It is 2 grams per serving of Nutritional Yeast Tablets.