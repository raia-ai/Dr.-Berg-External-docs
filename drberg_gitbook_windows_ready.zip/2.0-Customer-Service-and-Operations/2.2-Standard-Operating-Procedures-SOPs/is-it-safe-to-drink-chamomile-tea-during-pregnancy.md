# Is it safe to drink chamomile tea during pregnancy?

No, there is some evidence that regularly drinking chamomile tea during pregnancy can increase the risk of low birth weight and preterm labor.