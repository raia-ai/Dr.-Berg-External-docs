# Does Chewable Vitamin C Complex with Organic Berries Non-GMO contain soy, wheat, dairy or nuts?

Our Chewable Vitamin C Complex is formulated without common allergens, including soy, wheat, dairy, and nuts.