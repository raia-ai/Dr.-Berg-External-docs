# Where are the probiotics in Friendly Bacteria Probiotic sourced from?

Probiotics are sourced from naturally occurring microbes in the gut.