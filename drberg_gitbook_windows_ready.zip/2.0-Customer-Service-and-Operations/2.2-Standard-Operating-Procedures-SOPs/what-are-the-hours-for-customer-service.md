# What are the hours for Customer Service

Customer Service is open Monday-Friday from 8am-10pm ESTSaturday and Sunday from 9am-6pm EST