# Does Adrenal Glandular supplement contain soy, wheat, milk or dairy?

Our Adrenal Glandular is formulated without common allergens, including soy, wheat, dairy, and nuts.