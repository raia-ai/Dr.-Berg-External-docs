# What type of biotin is used in Biotin Shampoo & Conditioner?

The type of biotin used in our Biotin Shampoo & Conditioner is D-biotin.