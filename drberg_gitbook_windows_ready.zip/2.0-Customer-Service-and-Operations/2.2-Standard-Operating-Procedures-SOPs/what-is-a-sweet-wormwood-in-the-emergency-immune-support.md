# What is a sweet wormwood in the Emergency Immune Support?

Sweet wormwood, used in our Emergency Immune Support, is an herb.