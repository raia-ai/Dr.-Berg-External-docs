# Can I take more than the recommended daily serving of Multi Collagen Peptides?

We do not recommend extending daily serving of Multi Collagen Peptides. Daily serving is 1 scoop of the powder.