# Where is the pectin in the Probiotic with Prebiotic Blend sourced from?

The pectin that makes up the acid-resistant vegetable capsule is sourced from apples.