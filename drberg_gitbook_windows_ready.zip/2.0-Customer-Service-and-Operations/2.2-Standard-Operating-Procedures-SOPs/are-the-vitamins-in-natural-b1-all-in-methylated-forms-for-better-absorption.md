# Are the vitamins in Natural B1+ all in methylated forms for better absorption?

Our Natural B1+ offers a methylated B-complex, ensuring you get the active forms of these essential vitamins.