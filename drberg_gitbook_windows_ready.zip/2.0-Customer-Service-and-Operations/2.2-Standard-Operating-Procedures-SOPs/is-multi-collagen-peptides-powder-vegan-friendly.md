# Is Multi Collagen Peptides powder vegan-friendly?

Unfortunately no. Collagen Peptides powder contains chicken collagen and fish collagen.