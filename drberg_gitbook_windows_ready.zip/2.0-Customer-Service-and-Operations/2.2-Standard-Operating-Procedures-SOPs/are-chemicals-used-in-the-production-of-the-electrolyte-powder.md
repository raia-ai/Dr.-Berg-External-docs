# Are chemicals used in the production of the Electrolyte Powder?

Our Electrolyte Powder and the natural fruit flavors are processed without any chemicals. We use a proprietary method to ensure a pure and delicious product.