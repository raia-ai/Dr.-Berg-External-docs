# What root is used as the source of berberine in Blood Sugar Support Advanced?

Our Blood Sugar Support Advanced Formula harnesses the power of berberine, sourced directly from Indian barberry and turmeric root, to promote healthy blood sugar levels.