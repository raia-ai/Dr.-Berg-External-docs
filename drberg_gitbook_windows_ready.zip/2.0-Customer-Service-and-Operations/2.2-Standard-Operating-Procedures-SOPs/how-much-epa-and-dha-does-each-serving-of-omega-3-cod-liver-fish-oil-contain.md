# How much EPA and DHA does each serving of Omega 3 Cod Liver Fish Oil contain?

Each serving of Omega 3 Cod Liver Fish Oil contains 110 mg of EPA and 125 mg of DHA per serving.