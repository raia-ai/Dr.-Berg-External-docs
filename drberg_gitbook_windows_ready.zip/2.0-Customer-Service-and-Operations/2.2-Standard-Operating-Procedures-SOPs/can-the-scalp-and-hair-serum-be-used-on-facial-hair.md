# Can the Scalp and Hair Serum be used on facial hair?

We recommend following the suggested usage. Anything outside of this is at your own discretion.