# Is it safe to use Nerve Support with Benfotiamine if it has been exposed to freezing temperatures?

Don't worry, your Nerve Support supplement is perfectly fine to use even if it gets cold or freezes. These temperature changes won't affect its quality.