# Where is the Self-Massage Tool manufactured?

Dr. Berg self-massage tool is proudly made in the USA.