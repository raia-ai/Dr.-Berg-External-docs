# Does Organic Greens Superfood - Cruciferous Blend contain soy, wheat, diary or nuts?

Our Organic Greens Superfood Cruciferous Blend is formulated without common allergens, including soy, wheat, dairy, and nuts.