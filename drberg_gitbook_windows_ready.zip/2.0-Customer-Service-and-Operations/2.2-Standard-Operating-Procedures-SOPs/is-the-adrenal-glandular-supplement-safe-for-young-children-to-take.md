# Is the Adrenal Glandular supplement safe for young children to take?

The Adrenal Glandular label states: Pregnant or nursing mothers, children under the age of 18, and individuals with known medical conditions should consult a physician before using this or any dietary supplement. We do not recommend this product for children.