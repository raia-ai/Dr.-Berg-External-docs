# Why do I feel exhausted but can’t sleep?

Being unable to fall asleep despite feeling exhausted can be caused by snacking too close to bedtime, consuming alcohol, frequent need to urinate at night, blood sugar imbalances, and vitamin D deficiency. In some cases, being unable to sleep can be a symptom of a sleep disorder such as sleep apnea, circadian rhythm disorder, or hormonal imbalances.