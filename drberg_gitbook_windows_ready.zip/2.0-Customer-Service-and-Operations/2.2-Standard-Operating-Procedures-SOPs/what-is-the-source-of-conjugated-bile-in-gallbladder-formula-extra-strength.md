# What is the source of conjugated bile in Gallbladder Formula Extra Strength?

Our Gallbladder Formula Extra Strength uses conjugated bile salts derived from ox bile. While closely related, conjugated bile salts and ox bile have slightly different compositions listed separately on the ingredients label.