# Does Turmeric Curcumin with Bioperine supplement contain soy, wheat, diary or nuts?

Our Turmeric Curcumin with Bioperine is formulated without common allergens, including soy, wheat, dairy, and nuts.