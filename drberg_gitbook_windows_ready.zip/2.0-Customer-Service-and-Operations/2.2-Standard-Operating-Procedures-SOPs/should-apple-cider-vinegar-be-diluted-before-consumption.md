# Should apple cider vinegar be diluted before consumption?

Yes, it’s crucial to dilute apple cider vinegar as it’s highly acidic. Consuming it undiluted can lead to tooth enamel erosion and may irritate the mucosal lining of the throat, esophagus, and stomach. https://hls-player.drberg.com/asset?path=migrated-assets/when-to-consume-the-apple-cider-vinegar-acv-drink-drberg