# Does Ashwagandha with BioPerine (Black Pepper) contain soy, wheat, dairy or nuts?

Our Ashwagandha with Black Pepper is formulated without common allergens, including soy, wheat, dairy, and nuts.