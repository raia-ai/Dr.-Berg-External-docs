# Does the Biotin Conditioner come with a safety seal?

The Biotin Conditioner is shipped with a safety seal under the cap.Does the Biotin Conditioner arrive with a safety seal?