# What is the amount of tyrosine in L-Theanine Adrenal Support?

We're always committed to transparency, but the specific amount of tyrosine in our L-Theanine Adrenal Support is part of our proprietary blend. We carefully selected this ingredient for its potential to support adrenal health and manage stress levels.