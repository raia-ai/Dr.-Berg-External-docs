# From which country is the allithiamine in Natural B1+ sourced?

We source the allithiamine in our Natural B1+ from China.