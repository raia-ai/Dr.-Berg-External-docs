# Does Magnesium Glycinate supplement contain yeast?

We cannot confirm that Magnesium Glycinate is completely yeast-free. However, we do know that it contains less than 10 CFU (colony-forming units) of yeast per gram.