# Are eggs suitable for a keto diet?

Absolutely. Eggs are an excellent source of dietary fat and protein—and they’re low in carbs! https://hls-player.drberg.com/asset?path=migrated-assets/why-should-you-include-egg-yolks-on-keto-diet-intermittent-fasting-plan-drberg