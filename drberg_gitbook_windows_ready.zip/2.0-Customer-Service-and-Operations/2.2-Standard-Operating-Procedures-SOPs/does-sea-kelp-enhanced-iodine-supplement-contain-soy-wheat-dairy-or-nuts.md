# Does Sea Kelp Enhanced Iodine supplement contain soy, wheat, dairy or nuts?

Our Sea Kelp Enhanced Iodine is formulated without common allergens, including soy, wheat, dairy, and nuts.