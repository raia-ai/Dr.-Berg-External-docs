# Which brand of inulin prebiotic did Dr. Berg use for making L. Reuteri yogurt?

In the video "Fix Your Gut with ONE Microbe," Dr. Berg used the It's Just Inulin Prebiotic Brand.https://hls-player.drberg.com/asset?path=migrated-assets/youtube-videos-fix-your-gut-with-this-one