# How long is it safe to take Friendly Bacteria Probiotic Liquid?

You can take our Friendly Bacteria Probiotic for as long as it benefits you.