# What is the amount of Lactobacillus Acidophilus in the Probiotic with Prebiotic Blend?

Lactobacillus acidophilus is naturally found in many probiotic sources. While the exact ratios of individual strains in our Probiotic can vary slightly, we ensure that each batch contains a total of 60 billion CFUs (colony-forming units) at the time of manufacture.