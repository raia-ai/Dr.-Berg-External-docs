# What type of yogurt does Dr. Berg recommend for health benefits?

Dr. Berg recommends plain whole milk yogurt from grass-fed A2 protein cows or Bulgarian yogurt.