# How long is Friendly Bacteria Probiotic Liquid good for after it has been opened?

Our Friendly Bacteria Probiotic has a shelf life of one year, whether it's unopened or opened after you receive it.