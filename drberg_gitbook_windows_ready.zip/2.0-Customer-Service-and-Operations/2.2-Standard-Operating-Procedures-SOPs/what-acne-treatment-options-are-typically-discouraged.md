# What acne treatment options are typically discouraged?

Avoid popping pimples which can lead to scarring.Skip harsh scrubs that may irritate your skin.Lay off greasy cosmetics that can clog pores.Ditch alcohol-based toners, which might dry out your skin excessively.https://hls-player.drberg.com/asset?path=migrated-assets/the-fastest-way-to-rid-acne-drberg