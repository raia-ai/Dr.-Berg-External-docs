# Is Magnesium Glycinate supplement nut & shellfish free?

Our Magnesium Glycinate is allergen-free. However, it's important for those with severe allergies to know they are processed in a facility that handles nuts and shellfish.