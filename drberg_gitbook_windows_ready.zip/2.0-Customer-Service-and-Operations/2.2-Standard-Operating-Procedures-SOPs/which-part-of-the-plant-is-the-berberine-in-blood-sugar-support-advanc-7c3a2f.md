# Which part of the plant is the berberine in Blood Sugar Support Advanced Formula extracted from?

Our Blood Sugar Support Advanced Formula uses berberine derived from the root of the plant.