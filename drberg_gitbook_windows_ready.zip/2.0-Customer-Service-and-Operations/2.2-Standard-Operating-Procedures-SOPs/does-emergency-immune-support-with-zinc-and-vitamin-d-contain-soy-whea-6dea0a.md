# Does Emergency Immune Support with Zinc and Vitamin D contain soy, wheat, dairy or nuts?

Our Emergency Immune Support is formulated without common allergens, including soy, wheat, dairy, and nuts.