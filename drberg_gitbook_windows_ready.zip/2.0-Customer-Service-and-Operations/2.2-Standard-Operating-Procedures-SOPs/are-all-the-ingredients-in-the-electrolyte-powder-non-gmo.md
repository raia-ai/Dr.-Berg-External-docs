# Are all the ingredients in the Electrolyte Powder non-GMO?

Our Electrolyte Powder isn't currently Non-GMO Project Verified, but we're committed to non-GMO sourcing. All ingredients are carefully selected from non-GMO suppliers.