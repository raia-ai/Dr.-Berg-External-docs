# Does Multi Collagen Peptides powder clump when mixed with water or a drink?

The difference between other collagen peptide powders and Dr. Berg's Multi Collagen Peptides powder, is that Dr. Berg's Collagen peptides powder doesn't clump up. It dissolves fast and flows smoothly.