# What is the best way to take Dr. Berg Niacin 500 mg?

Niacin is best taken with a large meal to help lessen the "niacin flush." We recommend not taking it on an empty stomach or before bed.