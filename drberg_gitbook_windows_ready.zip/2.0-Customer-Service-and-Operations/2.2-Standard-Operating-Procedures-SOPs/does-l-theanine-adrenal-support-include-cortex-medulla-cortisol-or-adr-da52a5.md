# Does L-Theanine Adrenal Support include cortex, medulla, cortisol, or adrenaline in its ingredients?

Our L-Theanine Adrenal Support does not contain adrenal cortex, medulla, cortisol, or adrenaline.