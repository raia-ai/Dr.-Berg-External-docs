# Does the stevia in Dr. Berg's Electrolyte Powder contain carbohydrates?

Our Electrolyte Powder has just 2 net carbs and 15 calories per scoop. It's sweetened with organic stevia 98% Reb A for a sugar-free boost.