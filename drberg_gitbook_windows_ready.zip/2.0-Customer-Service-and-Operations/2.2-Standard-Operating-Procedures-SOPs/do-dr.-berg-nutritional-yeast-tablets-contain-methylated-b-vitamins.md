# Do Dr. Berg Nutritional Yeast Tablets contain methylated B vitamins?

The B vitamins in our Nutritional Yeast Tablets are naturally methylated.