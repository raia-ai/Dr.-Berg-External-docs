# Does Dr. Berg recommend any brand of soda?

Dr. Berg recommends Zevia brand beverages as a healthier alternative. Zevia is sweetened with stevia and contains no artificial colors.