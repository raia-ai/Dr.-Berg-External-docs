# Is the D3 & K2 nut & shell fish free?

Our D3 & K2 themselves are allergen-free. However, it's important for those with severe allergies to know they are processed in a facility that handles nuts and shellfish.