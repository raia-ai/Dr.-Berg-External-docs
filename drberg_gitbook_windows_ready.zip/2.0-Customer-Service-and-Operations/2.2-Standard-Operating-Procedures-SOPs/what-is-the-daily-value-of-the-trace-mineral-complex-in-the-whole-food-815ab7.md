# What is the daily value of the trace mineral complex in the Whole Food Multivitamin?

Our Whole Food Multivitamin doesn't list a Daily Value for trace minerals because it contains a complex of over 70 different minerals. Daily Values are established for individual nutrients, not complex blends.