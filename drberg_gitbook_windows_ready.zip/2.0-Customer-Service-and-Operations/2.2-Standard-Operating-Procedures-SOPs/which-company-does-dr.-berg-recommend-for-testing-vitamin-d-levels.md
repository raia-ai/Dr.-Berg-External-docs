# Which company does Dr. Berg recommend for testing Vitamin D levels?

Dr. Berg recommends Omegaquant to have your vitamin D levels tested: https://omegaquant.com/vitamin-d-test/