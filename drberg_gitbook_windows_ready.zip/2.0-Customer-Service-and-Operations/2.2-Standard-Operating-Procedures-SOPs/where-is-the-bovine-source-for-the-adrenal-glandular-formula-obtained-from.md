# Where is the bovine source for the Adrenal Glandular Formula obtained from?

We source the grass-fed bovine for our Adrenal Glandular Formula from Argentina.