# Are the animal-derived ingredients in L-Theanine Adrenal Support sourced from bovines that received the mRNA vaccine?

The bovine used in our L-Theanine Adrenal Support were not given the mRNA vaccine.