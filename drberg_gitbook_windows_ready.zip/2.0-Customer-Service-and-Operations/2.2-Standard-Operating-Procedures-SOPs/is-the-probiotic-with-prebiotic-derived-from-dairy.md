# Is the Probiotic with Prebiotic derived from dairy?

Our Probiotic is dairy-free. Its strains are derived from naturally occurring gut microbes.