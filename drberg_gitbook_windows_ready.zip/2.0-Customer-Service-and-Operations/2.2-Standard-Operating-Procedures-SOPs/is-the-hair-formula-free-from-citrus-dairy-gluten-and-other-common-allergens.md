# Is the Hair Formula free from citrus, dairy, gluten, and other common allergens?

This product has Hydrolyzed Fish Collagen in it so it is not free of all allergens.