# How are the fruits processed for the Electrolyte Powder?

Dr. Berg Electrolyte Powder is flavored by a proprietary process using only natural fruit extracts – no artificial chemicals.