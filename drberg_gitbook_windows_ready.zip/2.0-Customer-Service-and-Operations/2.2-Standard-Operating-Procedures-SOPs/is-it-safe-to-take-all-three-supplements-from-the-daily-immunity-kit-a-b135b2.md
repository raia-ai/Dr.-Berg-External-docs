# Is it safe to take all three supplements from the Daily Immunity Kit at the same time?

Yes, all 3 products of Daily Immunity Kit are safe to take together.