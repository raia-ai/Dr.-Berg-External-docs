# What are the yellow & red flakes in the Electrolyte Powder?

The yellow and reddish flakes in the Electrolyte Powder likely come from the natural flavoring ingredients.