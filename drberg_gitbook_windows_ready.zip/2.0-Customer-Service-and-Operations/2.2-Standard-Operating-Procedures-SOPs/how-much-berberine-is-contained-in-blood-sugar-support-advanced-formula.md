# How much berberine is contained in Blood Sugar Support Advanced Formula?

Blood Sugar Support Advanced Formula contains 75mg of berberine.