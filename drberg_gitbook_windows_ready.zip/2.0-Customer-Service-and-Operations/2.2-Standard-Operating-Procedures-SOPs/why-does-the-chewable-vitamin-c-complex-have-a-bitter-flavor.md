# Why does the Chewable Vitamin C Complex have a bitter flavor?

Our Chewable Vitamin C Complex is designed to have a pleasant, slightly tart berry flavor. A touch of bitterness can sometimes occur due to natural variations in the ingredients, but it shouldn't be overwhelming.