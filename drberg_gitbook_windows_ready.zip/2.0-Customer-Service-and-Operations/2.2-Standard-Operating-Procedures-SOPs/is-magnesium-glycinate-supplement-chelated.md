# Is Magnesium Glycinate supplement chelated?

Magnesium Glycinate is chelated.