# Does the Biotin Shampoo come with a safety seal?

The Biotin Shampoo is shipped with a safety seal under the cap.