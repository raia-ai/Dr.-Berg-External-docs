# What is the amount of oxalates in the Whole Food Multivitamin?

The Whole Food Multivitamin has not been tested for its oxalate content. However, it does contain ingredients from whole-food vegetables that may contain oxalates.