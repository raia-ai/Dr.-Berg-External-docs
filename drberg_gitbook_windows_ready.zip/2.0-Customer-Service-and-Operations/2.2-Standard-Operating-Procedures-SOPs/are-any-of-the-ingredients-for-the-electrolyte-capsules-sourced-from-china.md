# Are any of the ingredients for the Electrolyte Capsules sourced from China?

To confirm, we do not source any ingredients from China for our Electrolyte Capsules.