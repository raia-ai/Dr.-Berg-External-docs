# Why was the formula of the Biotin Shampoo & Conditioner changed?

Dr. Berg's dedication to constant improvement led him to discover even purer, more natural ingredients for his Biotin Shampoo and Conditioner. We've enhanced this formula by replacing some old ingredients and introducing new ones.