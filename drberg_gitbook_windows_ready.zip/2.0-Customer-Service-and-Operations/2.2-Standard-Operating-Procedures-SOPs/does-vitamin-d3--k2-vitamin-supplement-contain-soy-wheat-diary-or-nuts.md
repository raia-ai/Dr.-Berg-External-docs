# Does Vitamin D3 & K2 Vitamin supplement contain soy, wheat, diary or nuts?

Our D3 & K2 vitamins are formulated without common allergens, including soy, wheat, dairy, and nuts.