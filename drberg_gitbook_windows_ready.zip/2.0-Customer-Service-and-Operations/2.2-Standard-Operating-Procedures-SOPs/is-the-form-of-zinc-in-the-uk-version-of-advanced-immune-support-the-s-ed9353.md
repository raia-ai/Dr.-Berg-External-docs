# Is the form of zinc in the UK version of Advanced Immune Support the same as in the US version?

Our UK Advanced Immune Support Formula uses zinc sulfate, a naturally occurring mineral form of zinc. The US version utilizes zinc picolinate, which is zinc chelated with picolinic acid for potentially enhanced absorption.