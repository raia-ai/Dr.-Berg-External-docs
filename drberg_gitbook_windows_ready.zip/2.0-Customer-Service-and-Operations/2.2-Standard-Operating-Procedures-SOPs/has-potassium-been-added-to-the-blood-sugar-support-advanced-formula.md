# Has potassium been added to the Blood Sugar Support Advanced Formula?

Yes, 8mg of potassium has been added to the Blood Sugar Advanced Formula.