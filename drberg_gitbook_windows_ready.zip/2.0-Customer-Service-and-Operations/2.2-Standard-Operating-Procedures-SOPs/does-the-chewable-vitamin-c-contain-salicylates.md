# Does the Chewable Vitamin C contain salicylates?

Our Chewable Vitamin C is salicylate-free.