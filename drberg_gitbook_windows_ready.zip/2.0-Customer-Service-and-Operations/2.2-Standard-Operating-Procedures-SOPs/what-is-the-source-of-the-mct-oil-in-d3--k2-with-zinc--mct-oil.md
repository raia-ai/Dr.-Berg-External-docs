# What is the source of the MCT oil in D3 & K2 with Zinc & MCT Oil?

The MCT oil in our D3 & K2 with Zinc & MCT Oil is derived from coconuts.