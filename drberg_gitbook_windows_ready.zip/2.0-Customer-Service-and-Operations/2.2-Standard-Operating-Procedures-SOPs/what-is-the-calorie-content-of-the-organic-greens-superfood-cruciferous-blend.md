# What is the calorie content of the Organic Greens Superfood Cruciferous Blend?

We haven't tested the specific calorie content of our Organic Greens Superfood Cruciferous Blend and don't have plans to do so.