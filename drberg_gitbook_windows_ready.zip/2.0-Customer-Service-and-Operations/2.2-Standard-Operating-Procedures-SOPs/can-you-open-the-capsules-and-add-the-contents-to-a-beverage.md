# Can you open the capsules and add the contents to a beverage?

We strongly suggest against opening our capsules and taking them with water. Our supplements are specifically designed not to be opened. If you decide to open them, please understand you are doing so at your discretion.