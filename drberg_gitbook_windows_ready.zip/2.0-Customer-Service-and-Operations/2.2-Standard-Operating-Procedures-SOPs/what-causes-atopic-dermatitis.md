# What causes atopic dermatitis?

Atopic dermatitis is usually related to digestion. There could be a vitamin B3 deficiency but I think mainly what I would do is I would really evaluate your what you're eating and your digestion because that is a huge connection between eating the wrong foods and then your skin becoming inflamed.