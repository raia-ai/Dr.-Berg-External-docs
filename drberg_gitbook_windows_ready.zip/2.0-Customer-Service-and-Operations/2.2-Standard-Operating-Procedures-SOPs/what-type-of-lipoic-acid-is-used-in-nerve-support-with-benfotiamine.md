# What type of lipoic acid is used in Nerve Support with Benfotiamine?

Nerve Support with Benfotiamine contains Alpha-Lipoic acid.