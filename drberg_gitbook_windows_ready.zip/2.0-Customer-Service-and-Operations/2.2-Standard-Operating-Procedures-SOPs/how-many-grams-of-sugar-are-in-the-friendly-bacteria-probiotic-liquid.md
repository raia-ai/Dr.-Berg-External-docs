# How many grams of sugar are in the Friendly Bacteria Probiotic Liquid?

Our Friendly Bacteria Probiotic contains less than 1 gram of cane sugar (molasses) per bottle.