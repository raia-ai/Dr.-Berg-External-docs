# How many capsules of Glucosamine Chondroitin Advanced Joint Support with MSM can I take per day?

The recommended daily serving of our Glucosamine Chondroitin Advanced Joint Support is four capsules.