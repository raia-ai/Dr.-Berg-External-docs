# Does Trace Minerals Enhanced supplement contain soy, wheat, dairy or nuts?

Our Trace Minerals Enhanced are formulated without common allergens, including soy, wheat, dairy, and nuts.