# Are Dr. Berg Electrolyte Capsules free from soy?

Our Electrolyte Capsules do not contain soy.