# Why doesn't the Raw Organic Wheatgrass Juice Powder list all the vitamins & minerals?

The Raw Organic Wheatgrass Juice Powder is considered a food product, so it displays a Nutrition Facts label. Dietary supplements have a Supplement Facts label, which provides detailed information on vitamins and minerals.