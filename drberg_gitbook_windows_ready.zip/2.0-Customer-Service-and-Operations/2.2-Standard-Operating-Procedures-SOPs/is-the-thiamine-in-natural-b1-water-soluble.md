# Is the thiamine in Natural B1+ water-soluble?

Our Natural B1+ primarily uses Allithiamine, a fat-soluble form of B1. It also includes some water-soluble thiamine derived from the vegetables in the B complex.