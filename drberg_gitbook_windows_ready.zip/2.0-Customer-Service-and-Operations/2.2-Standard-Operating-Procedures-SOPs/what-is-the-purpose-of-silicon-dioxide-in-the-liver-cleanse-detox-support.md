# What is the purpose of Silicon Dioxide in the Liver Cleanse Detox Support?

Our Gallbladder Formula Extra Strength includes silicon dioxide, a safe and common anti-caking agent. Silicon dioxide is classified as GRAS (Generally Recognized as Safe) by both the USDA and FDA.