# What material are the teabags for Turmeric Ginger Tea made of?

Our Turmeric Ginger tea bags are made from plant-based PLA (Polylactic Acid) for a compostable, eco-friendly brewing experience.