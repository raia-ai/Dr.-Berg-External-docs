# What can cause stomach ulcers?

H. pylori bacteria is one of the most common causes of stomach ulcers. Stress, NSAID drugs, alcohol, excess coffee, and poor diet can also cause stomach ulcers.