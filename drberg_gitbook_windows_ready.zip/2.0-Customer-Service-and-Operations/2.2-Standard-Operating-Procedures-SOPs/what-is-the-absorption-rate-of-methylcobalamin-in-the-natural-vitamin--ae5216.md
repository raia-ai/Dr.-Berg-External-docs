# What is the absorption rate of methylcobalamin in the Natural Vitamin B12 supplement?

The typical absorption rate of methylcobalamin is 1%. This is for all methylcobalamin, not just our Natural Vitamin B12. This is why we have 41,667%. 1% is 416% absorbed.