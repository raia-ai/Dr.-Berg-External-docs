# How many tablets of Advanced Digestive Enzymes are equivalent to 1 tablespoon of apple cider vinegar?

Determining the liquid ACV equivalent would require extensive testing. The formula for our Advanced Digestive Enzymes uses concentrated, powdered apple cider vinegar. Rest assured that each tablet offers a high potency per serving.