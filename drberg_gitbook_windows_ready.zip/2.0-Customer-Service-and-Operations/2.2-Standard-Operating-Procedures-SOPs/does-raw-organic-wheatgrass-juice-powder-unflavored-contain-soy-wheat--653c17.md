# Does Raw Organic Wheatgrass Juice Powder (Unflavored) contain soy, wheat, dairy or nuts?

Our Raw Organic Wheatgrass Juice Powder is formulated without common allergens, including soy, dairy, and nuts. Wheatgrass juice is made from the young, sprouted leaves of the wheat plant, not from the wheat kernel itself.