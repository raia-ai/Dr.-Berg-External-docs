# Is the thiamine (B1) in Natural B1+ natural or synthetic?

The vitamin B1 (thiamine) in our Natural B1+ is derived directly from a whole-food B vitamin complex blend including broccoli (flower and stem), carrot (root), spinach (leaf), sunflower seed, and chlorella.