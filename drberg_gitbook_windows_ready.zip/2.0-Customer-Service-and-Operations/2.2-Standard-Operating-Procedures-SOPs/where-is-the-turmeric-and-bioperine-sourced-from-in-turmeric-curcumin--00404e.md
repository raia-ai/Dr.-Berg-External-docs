# Where is the turmeric and BioPerine sourced from in Turmeric Curcumin with BioPerine?

The turmeric and bioperine in our Turmeric Curcumin with BioPerine are sourced from China and India.