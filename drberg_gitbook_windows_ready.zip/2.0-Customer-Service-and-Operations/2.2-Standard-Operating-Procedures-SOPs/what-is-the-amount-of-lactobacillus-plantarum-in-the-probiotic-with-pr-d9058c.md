# What is the amount of Lactobacillus Plantarum in the Probiotic with Prebiotic Blend?

The exact amount of Lactobacillus plantarum in Dr. Berg Probiotic can vary slightly between batches. To get the most accurate information for a specific batch, it would need to be tested.