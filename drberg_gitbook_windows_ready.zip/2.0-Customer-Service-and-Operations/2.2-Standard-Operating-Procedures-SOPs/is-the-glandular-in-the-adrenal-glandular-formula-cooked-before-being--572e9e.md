# Is the glandular in the Adrenal Glandular Formula cooked before being freeze-dried?

The glandular in our Adrenal Glandular Formula is freeze-dried without the use of heat. This preserves its natural qualities and allows you to get the most nutrients possible.