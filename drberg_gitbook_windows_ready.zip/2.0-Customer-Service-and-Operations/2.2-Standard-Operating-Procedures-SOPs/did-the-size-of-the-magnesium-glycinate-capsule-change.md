# Did the size of the Magnesium Glycinate capsule change?

Dr. Berg Magnesium Glycinate capsules are now slightly smaller than the previous version.