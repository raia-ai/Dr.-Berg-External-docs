# Does the Chewable Vitamin C contain lectins?

Our Chewable Vitamin C Complex is lectin-free.