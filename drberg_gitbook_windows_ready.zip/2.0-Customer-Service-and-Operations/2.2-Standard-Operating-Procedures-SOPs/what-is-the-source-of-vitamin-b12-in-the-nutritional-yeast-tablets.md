# What is the source of vitamin B12 in the Nutritional Yeast Tablets?

The B12 (methylocobalamin) in our Nutritional Yeast is sourced from China.