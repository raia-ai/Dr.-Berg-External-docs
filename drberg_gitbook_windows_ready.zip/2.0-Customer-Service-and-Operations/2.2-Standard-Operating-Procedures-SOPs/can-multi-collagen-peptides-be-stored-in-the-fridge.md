# Can Multi Collagen Peptides be stored in the fridge?

We recommend storing Multi Collagen Peptides powder in a cool and dry place.