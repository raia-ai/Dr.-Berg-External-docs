# Is soy included in the ingredients of the Electrolyte Powder?

Our Electrolyte Powder doesn't contain soy as an ingredient. We understand the need for absolute certainty for those with severe soy allergies. You may wish to have the product independently tested.