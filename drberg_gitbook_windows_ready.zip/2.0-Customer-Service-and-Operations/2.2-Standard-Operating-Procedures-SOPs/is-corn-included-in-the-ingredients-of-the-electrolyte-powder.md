# Is corn included in the ingredients of the Electrolyte Powder?

Enjoy the benefits of Dr. Berg Electrolyte Powder without any worries – it's formulated without corn.