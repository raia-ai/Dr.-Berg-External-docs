# What brands of water filters does Dr. Berg recommend?

Here are the links of water filters that Dr. Berg recommends:https://www.amazon.com/Travel-Berkey-Gravity-Fed-Purification-Elements/dp/B00FMUYU6Ihttps://www.amazon.com/ZeroWater-7-Cup-Water-Filter-Pitcher/dp/B0722YFFCQ?th=1https://clearlyfiltered.com/products/clean-water-pitcher