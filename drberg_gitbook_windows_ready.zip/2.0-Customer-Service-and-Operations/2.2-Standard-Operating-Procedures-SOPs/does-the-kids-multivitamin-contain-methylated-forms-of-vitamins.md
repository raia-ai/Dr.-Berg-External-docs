# Does the Kids Multivitamin contain methylated forms of vitamins?

Our Kids Multivitamin uses methylated vitamins for better absorption.