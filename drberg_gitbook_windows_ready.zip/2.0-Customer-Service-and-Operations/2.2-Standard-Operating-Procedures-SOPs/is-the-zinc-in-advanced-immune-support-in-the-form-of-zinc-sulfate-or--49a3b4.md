# Is the zinc in Advanced Immune Support in the form of zinc sulfate or zinc picolinate?

Our Advanced Immune Support features zinc picolinate, a highly absorbable form of zinc for maximum immune benefits.