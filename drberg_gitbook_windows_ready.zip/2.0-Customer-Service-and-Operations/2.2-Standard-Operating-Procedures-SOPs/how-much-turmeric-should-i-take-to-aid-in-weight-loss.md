# How much turmeric should I take to aid in weight loss?

Evidence suggests that taking between 1,000 and 1,500 milligrams of turmeric daily is associated with a significant reduction in body weight, waist circumference, and body mass index.