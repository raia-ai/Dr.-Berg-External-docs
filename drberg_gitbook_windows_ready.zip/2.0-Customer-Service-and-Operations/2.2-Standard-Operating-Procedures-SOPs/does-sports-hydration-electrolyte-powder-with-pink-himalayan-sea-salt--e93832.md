# Does Sports Hydration Electrolyte Powder with Pink Himalayan Sea Salt contain soy, wheat, dairy or nuts?

Our Sports Hydration Electrolyte Powder is formulated without common allergens, including soy, wheat, dairy, and nuts.