# Does Natural Prenatal Vitamin contain soy, wheat, diary or nuts?

Our Natural Prenatal Vitamins are formulated without common allergens, including soy, wheat, dairy, and nuts.