# Does L-Theanine Adrenal Support - 200 mg of L-Theanine contain soy, wheat, dairy or nuts?

Our L-Theanine Adrenal Support is formulated without common allergens, including soy, wheat, dairy, and nuts.