# What are the effects of fasting while breastfeeding?

Fasting can decrease milk supply and alter breast milk's composition, resulting in your infant not gaining appropriate weight and increasing the risk of nutrient deficiencies linked to stunted growth and weakened immune defenses. https://hls-player.drberg.com/asset?path=migrated-assets/what-to-eat-while-breastfeeding