# How many cups of Turmeric Ginger Tea are safe to drink each day?

Feel free to enjoy as many cups of our Turmeric Ginger Tea as you'd like – there's no limit!