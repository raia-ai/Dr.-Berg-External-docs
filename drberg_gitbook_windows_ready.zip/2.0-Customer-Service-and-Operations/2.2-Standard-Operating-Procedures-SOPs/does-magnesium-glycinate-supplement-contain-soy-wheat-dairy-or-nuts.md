# Does Magnesium Glycinate supplement contain soy, wheat, dairy or nuts?

Our Magnesium Glycinate is formulated without common allergens, including soy, wheat, dairy, and nuts.