# Does Kids Multivitamin No Sugar Added contain soy, wheat, dairy or nuts?

Our Kids Multivitamin is formulated without common allergens, including soy, wheat, dairy, and nuts.