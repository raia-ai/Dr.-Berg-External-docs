# Does Vitamin D3 & K2 with Zinc and MCT Oil require refrigeration after opening?

You can store our Vitamin D3 & K2 with Zinc and MCT Oil at room temperature after opening. Refrigeration is not necessary.