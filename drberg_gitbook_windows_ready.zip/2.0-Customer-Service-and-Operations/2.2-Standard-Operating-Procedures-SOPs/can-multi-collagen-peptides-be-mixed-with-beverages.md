# Can Multi Collagen Peptides be mixed with beverages?

Yes! Multi Collagen Peptides powder can be mixed with any average of your choice. The powder is unflavored so it won't affect the taste of your drink.