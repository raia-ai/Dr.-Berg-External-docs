# Is it safe to take both the Whole Food Multivitamin and Trace Minerals Enhanced together?

You can take both our Whole Food Multivitamin & our Trace Minerals Enhanced.