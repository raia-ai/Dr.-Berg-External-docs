# Do the Advanced Digestive Enzymes and Gallbladder Formula Extra Strength have the same source of pancreatin?

The Gallbladder Formula Extra Strength and the Advanced Digestive Enzymes use the same source of pancreatin: porcine (pork).