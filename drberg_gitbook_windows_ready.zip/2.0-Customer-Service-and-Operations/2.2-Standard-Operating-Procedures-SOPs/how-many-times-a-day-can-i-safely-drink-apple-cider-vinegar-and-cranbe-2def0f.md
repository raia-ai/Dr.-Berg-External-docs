# How many times a day can I safely drink apple cider vinegar and cranberry juice?

You can have apple cider vinegar and cranberry juice up to five times daily. However, if you notice gastrointestinal upset, including reflux or stomach pain, it’s best not to exceed three glasses of apple cider vinegar and cranberry juice daily.