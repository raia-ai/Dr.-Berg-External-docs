# How much curcumin does Turmeric Curcumin with Bioperine contain?

Our Turmeric Curcumin with Bioperine contains 150 mg of curcumin.