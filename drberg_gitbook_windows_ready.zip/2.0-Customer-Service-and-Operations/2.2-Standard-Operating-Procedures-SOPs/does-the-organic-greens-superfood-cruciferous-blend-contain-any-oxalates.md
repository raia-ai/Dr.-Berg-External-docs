# Does the Organic Greens Superfood Cruciferous Blend contain any oxalates?

Our Organic Greens Superfood Cruciferous Blend has not been tested for oxalate levels.