# What is the source of the vitamin B6 in Dr. Berg's Kids Chewable Multivitamin?

The vitamin B6 in Dr. Berg Kids Chewable Multivitamin comes from spinach, broccoli, and a special form called pyridoxal-5-phosphate.