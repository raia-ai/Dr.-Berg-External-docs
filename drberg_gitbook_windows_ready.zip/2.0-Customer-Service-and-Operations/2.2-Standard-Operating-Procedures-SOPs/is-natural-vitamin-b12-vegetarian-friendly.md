# Is Natural Vitamin B12 vegetarian-friendly?

Yes, Dr. Berg Natural Vitamin B12 is both vegetarian and vegan-friendly.