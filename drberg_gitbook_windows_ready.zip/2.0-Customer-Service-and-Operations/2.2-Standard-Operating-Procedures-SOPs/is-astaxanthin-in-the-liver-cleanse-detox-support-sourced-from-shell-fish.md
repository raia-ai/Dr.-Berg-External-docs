# Is astaxanthin in the Liver Cleanse Detox Support sourced from shell fish?

The astaxanthin in our Liver Cleanse Detox Repair Support is sourced from the freshwater microalga Haematococcus pluvialis (Chlorophyta).