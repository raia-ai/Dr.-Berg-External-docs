# Can you take TUDCA & Gallbladder Formula Extra Strength together?

When taking TUDCA, You may want to take one on an empty stomach. In addition to TUDCA, taking bile salts, like our Gallbladder Formula, with a meal could give you extra benefits if your symptoms are severe.