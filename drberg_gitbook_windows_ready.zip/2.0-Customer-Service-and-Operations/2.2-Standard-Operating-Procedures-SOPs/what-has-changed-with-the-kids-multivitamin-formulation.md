# What has changed with the Kids Multivitamin formulation?

Dr. Berg has decided to add more Acai Berry has been added and remove cellulose from the formulation.