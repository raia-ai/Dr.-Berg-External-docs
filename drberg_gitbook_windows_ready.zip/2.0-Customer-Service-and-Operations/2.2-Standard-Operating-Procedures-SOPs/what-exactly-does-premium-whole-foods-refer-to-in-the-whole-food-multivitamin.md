# What exactly does 'premium whole foods' refer to in the Whole Food Multivitamin?

We source all our vitamins from a blend of whole fruits and vegetables in our Whole Food Multivitamins.