# Why is potassium not included in Magnesium Glycinate?

Dr. Berg Magnesium Glycinate supplement combines magnesium with glycine, an amino acid, for improved absorption. We also include Vitamin D3 and Vitamin B6 to support this process. This product specifically focuses on magnesium, which is why potassium is not included. However, our Electrolyte Powder offers both magnesium and potassium.