# Where is the fruit sourced from in the Chewable Vitamin C Complex?

The fruit used in our Chewable Vitamin C Complex is sourced from Brazil and China.