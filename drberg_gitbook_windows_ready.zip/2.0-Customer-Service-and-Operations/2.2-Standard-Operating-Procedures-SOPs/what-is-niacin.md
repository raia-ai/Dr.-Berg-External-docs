# What is niacin?

Each serving of Dr. Berg Niacin delivers an incredible 500 mg of niacin, a superior form of vitamin B3 that’s easily absorbed and highly effective. https://hls-player.drberg.com/asset?path=migrated-assets/fixed-feb-17th-vitamin-b3