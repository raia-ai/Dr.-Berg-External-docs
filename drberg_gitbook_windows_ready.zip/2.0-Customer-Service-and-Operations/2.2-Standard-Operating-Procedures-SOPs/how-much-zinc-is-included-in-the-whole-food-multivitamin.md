# How much zinc is included in the Whole Food Multivitamin?

Our Whole Food Multivitamin includes zinc as part of its trace mineral complex. While the exact amount is part of our proprietary formula, you can trust that it delivers a beneficial dose of this essential mineral.