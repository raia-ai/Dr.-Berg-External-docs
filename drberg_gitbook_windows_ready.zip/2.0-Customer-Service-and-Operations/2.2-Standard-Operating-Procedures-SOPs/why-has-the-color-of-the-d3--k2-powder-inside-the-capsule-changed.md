# Why has the color of the D3 & K2 Powder inside the capsule changed?

The D3 & K2 capsules may naturally turn slightly yellow over time due to the K2 content. This is normal and doesn't affect the product's safety or effectiveness.