# What is the carbohydrate content of the Chewable Vitamin C Complex?

We do not currently have information on the carbohydrate content of our Chewable Vitamin C Complex.