# Why is Advanced Digestive Enzymes not certified organic?

We are actively pursuing organic certification for our Advanced Digestive Enzymes, just like some of our products. While this process is underway, it's important to note that this doesn't mean the ingredients aren't organic, or at least partially organic.