# What does 'aerial' mean in reference to sweet wormwood in the Emergency Immune Support?

Aerial means the above-ground parts of the sweet wormwood plant are used in our Emergency Immune Support.