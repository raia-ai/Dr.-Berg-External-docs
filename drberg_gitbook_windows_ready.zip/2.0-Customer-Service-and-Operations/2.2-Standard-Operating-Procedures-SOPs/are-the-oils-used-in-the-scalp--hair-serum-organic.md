# Are the oils used in the Scalp & Hair Serum organic?

Our Scalp & Hair Serum features a blend of organic oils.