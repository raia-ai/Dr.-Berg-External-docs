# How many times per day can I take Electrolyte Powder?

The recommended usage for all Electrolyte Powder products is one scoop. Do not exceed the recommended usage per day.