# Where do the probiotic strains in the Probiotic with Prebiotic come from?

Probiotics are sourced from naturally occurring microbes in the gut.