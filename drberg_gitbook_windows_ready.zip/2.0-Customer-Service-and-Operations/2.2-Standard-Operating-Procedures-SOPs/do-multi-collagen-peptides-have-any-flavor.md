# Do Multi Collagen Peptides have any flavor?

No, Multi Collagen Peptides have no flavor.