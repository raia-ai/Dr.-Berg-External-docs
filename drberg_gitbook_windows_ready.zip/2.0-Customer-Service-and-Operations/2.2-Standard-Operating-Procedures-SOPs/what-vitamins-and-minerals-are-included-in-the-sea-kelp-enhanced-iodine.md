# What vitamins and minerals are included in the Sea Kelp Enhanced Iodine?

Our Sea Kelp Enhanced Iodine contains no added vitamins or minerals. The Klamath blue-green algae powder and Iceland geothermal kelp powder in our proprietary blend provide naturally occurring nutrients.