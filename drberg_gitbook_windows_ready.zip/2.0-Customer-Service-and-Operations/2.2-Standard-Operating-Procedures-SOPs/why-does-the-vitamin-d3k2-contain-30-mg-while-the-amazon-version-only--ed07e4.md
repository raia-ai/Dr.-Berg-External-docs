# Why does the Vitamin D3K2 contain 30 mg, while the Amazon version only has 3.4 mg?

We've recently adjusted the amount of vitamin B6 in our D3/K2 10,000 IU formula from 30 mg to 3.4 mg. You'll find the updated version currently available on Amazon. Once the current stock on our website sells out, the new formula with the lower B6 content will be available for purchase.