# Does Nutritional Yeast contain folic acid?

No, Nutritional yeast contains folate.