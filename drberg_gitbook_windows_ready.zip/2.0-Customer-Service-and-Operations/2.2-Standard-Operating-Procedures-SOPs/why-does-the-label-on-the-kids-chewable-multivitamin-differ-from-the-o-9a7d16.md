# Why does the label on the Kids Chewable Multivitamin differ from the one shown on Amazon?

We apologize for the discrepancy in the labeling of our Kids Chewable Vitamins on Amazon. We are working to update this information as quickly as possible for accuracy. Please refer to our website for the most up-to-date product details.