# Can eating snacks make it harder to sleep?

Yes, snacking can disrupt your sleep cycles and may lead to sleep issues. Digestion requires energy and stimulates metabolic activity, which can interfere with restful sleep.