# Is the Kids Multivitamin made with organic ingredients?

Our Kids Multivitamin uses a blend of organic ingredients. However, the final product itself is not yet certified as organic.