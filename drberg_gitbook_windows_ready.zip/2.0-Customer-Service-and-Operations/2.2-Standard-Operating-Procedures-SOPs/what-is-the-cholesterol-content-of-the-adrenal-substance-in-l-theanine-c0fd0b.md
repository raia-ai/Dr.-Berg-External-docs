# What is the cholesterol content of the adrenal substance in L-Theanine Adrenal Support?

Dr. Berg L-Theanine Adrenal Support has not been tested for its cholesterol content from the Argentinian grass-fed desiccated adrenal substance (bovine). We do not plan to test our product at this time.